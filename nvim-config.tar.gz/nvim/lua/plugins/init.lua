return {
  {
    "stevearc/conform.nvim",
    -- event = 'BufWritePre', -- uncomment for format on save
    opts = require "configs.conform",
  },

  -- These are some examples, uncomment them if you want to see them work!
  {
    "neovim/nvim-lspconfig",
    config = function()
      require "configs.lspconfig"
    end,
  },
{
  'mrcjkb/rustaceanvim',
  -- To avoid being surprised by breaking changes,
  -- I recommend you set a version range
  version = '^9',
  -- This plugin implements proper lazy-loading (see :h lua-plugin-lazy).
  -- No need for lazy.nvim to lazy-load it.
  lazy = false,

  config = function()
    local mason_registry = require('mason-registry')
    local codelldb = mason_registry.get_package("codelldb")
    local extension_path = codelldb:get_install_path() .. "/extension/"
    local codelldb_path = extension_path .. "adapter/codelldb"
    local liblldb_path = extension_path.. "1ldb/1ib/liblldb.dylib"
    local cfg = require('rustaceanvim.config')

    vim.g.rustaceanvim = {
      dap = {
        adapter = cfg.get_codelldb_adapter(codelldb_path, liblldb_path),
      },
    }
  end
},

{
  'mfussenegger/nvim-dap',

  config = function()
    local dap, dapui = require("dap"), require("dapui")
    dap.listeners.before.attach.dapui_config = function()
      dapui.open( )
    end
    dap.listeners.before.launch.dapui_config = function()
      dapui.open( )
    end
    dap.listeners.before.event_terminated.dapui_config = function()
      dapui.close( )
    end
    dap.listeners.before.event_exited.dapui_config = function()
      dapui.close( )
    end
  end
},

{
  'rcarriga/nvim-dap-ui',
  dependencies = {"mfussenegger/nvim-dap", "nvim-neotest/nvim-nio"},
  config = function()
    require("dapui").setup()
  end,
},


{
  'rust-lang/rust.vim',
  ft = "rust",
  unit = function()
    vim.g.rustfmt_autosave = 1
  end
},

{
  'saecki/crates.nvim',
  ft = {"toml"},
  config = function()
    require("crates").setup {
      completion = {
        cmp = {
          enabled = true
        },
      },
    }
    require('cmp').setup.buffer({
      sources = { { name = "crates" }}
    })
  end
},



-- test new blink
  -- { import = "nvchad.blink.lazyspec" },

  -- {
  -- 	"nvim-treesitter/nvim-treesitter",
  -- 	opts = {
  -- 		ensure_installed = {
  -- 			"vim", "lua", "vimdoc",
  --      "html", "css"
  -- 		},
  -- 	},
  -- },
}
